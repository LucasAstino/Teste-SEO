

### Dependencies
* node
* npm
* gulp



# Rodar npm para instalar dependencias
npm install

# Start server
gulp watch

# start build
gulp 

# Executar o arquivo index.html com live server para poder visualizar a página
